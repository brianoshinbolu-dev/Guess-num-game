function tryagain(){
    location.assign("index.html");
}

// function WriteToFile(passForm) { 
 
//     set fso = CreateObject("Scripting.FileSystemObject");  
//     set s   = fso.CreateTextFile("filename.txt", True); 
 
//     var firstName = document.getElementById('Name'); 
//     var lastName  = document.getElementById('Whatsapp'); 
 
//     s.writeline("First Name :" + FirstName); 
//     s.writeline("Last Name :" + lastName); 
 
//     s.writeline("-----------------------------"); 
//     s.Close(); 
//  } 